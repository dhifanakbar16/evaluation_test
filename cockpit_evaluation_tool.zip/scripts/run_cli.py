
"""Command-line entry point.

Run with:
    python scripts/run_cli.py --image data/samples/sample_display.png --output data/output
"""
from __future__ import annotations
import argparse
from pathlib import Path

from cockpit_eval.config import paths
from cockpit_eval.io.image_io import read_image, save_image, save_csv
from cockpit_eval.detect.detector import detect_elements
from cockpit_eval.laws.law_registry import load_laws
from cockpit_eval.evaluate.evaluator import evaluate_elements_against_laws
from cockpit_eval.visualize.overlay import draw_elements
from cockpit_eval.visualize.reports import make_results_dataframe, save_heatmap_png

def main():
    parser = argparse.ArgumentParser(description="Cockpit Display Evaluator (scaffold)")
    parser.add_argument("--image", required=True, help="Path to input image")
    parser.add_argument("--output", default=str(paths.output_dir), help="Output folder")
    args = parser.parse_args()

    img_path = Path(args.image)
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    img = read_image(img_path)
    elements = detect_elements(img)
    laws = load_laws(paths.laws_yaml)

    results = evaluate_elements_against_laws(elements, laws)

    # Save CSV of detected elements (basic)
    elements_csv = out_dir / f"{img_path.stem}_elements.csv"
    save_csv(elements_csv, elements)

    # Save CSV of evaluation results
    results_csv = out_dir / f"{img_path.stem}_evaluation.csv"
    save_csv(results_csv, results)

    # Save overlay image
    overlay = draw_elements(img, elements)
    overlay_path = out_dir / f"{img_path.stem}_overlay.png"
    save_image(overlay_path, overlay)

    # Save heatmap
    import pandas as pd
    df = make_results_dataframe(results)
    heatmap_path = out_dir / f"{img_path.stem}_heatmap.png"
    save_heatmap_png(df, heatmap_path)

    print("Saved:")
    print(" -", elements_csv)
    print(" -", results_csv)
    print(" -", overlay_path)
    print(" -", heatmap_path)

if __name__ == "__main__":
    main()
