
"""Minimal Streamlit UI for the evaluator."""
import streamlit as st
from pathlib import Path
from cockpit_eval.io.image_io import read_image, save_image, save_csv
from cockpit_eval.detect.detector import detect_elements
from cockpit_eval.laws.law_registry import load_laws
from cockpit_eval.evaluate.evaluator import evaluate_elements_against_laws
from cockpit_eval.visualize.overlay import draw_elements
from cockpit_eval.visualize.reports import make_results_dataframe, save_heatmap_png
from cockpit_eval.config import paths
import pandas as pd
import tempfile
import cv2

st.title("Cockpit Display Evaluation (Scaffold)")

uploaded = st.file_uploader("Upload cockpit display image", type=["png","jpg","jpeg"])
if uploaded:
    # Write to a temp file so OpenCV can read it
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(uploaded.read())
        tmp_path = Path(tmp.name)

    img = read_image(tmp_path)
    st.image(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), caption="Input Image", use_container_width=True)

    if st.button("Run detection & evaluation"):
        elements = detect_elements(img)
        laws = load_laws(paths.laws_yaml)
        results = evaluate_elements_against_laws(elements, laws)

        # Overlay
        overlay = draw_elements(img, elements)
        st.image(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB), caption="Overlay", use_container_width=True)

        # Tables
        st.subheader("Detected elements")
        st.dataframe(pd.DataFrame(elements))

        st.subheader("Evaluation results")
        df = make_results_dataframe(results)
        st.dataframe(df)

        # Heatmap
        with tempfile.TemporaryDirectory() as td:
            heatmap_path = Path(td) / "heatmap.png"
            save_heatmap_png(df, heatmap_path)
            st.image(str(heatmap_path), caption="Heatmap", use_container_width=True)
