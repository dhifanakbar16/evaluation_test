
"""Tesseract OCR wrapper (optional).

- *OCR* = Optical Character Recognition (reading text from images).
- On Windows you may need to set tesseract_cmd to your install path.
"""
from __future__ import annotations
from typing import Dict, Any

import pytesseract
import cv2

# Example: uncomment and set your install path if needed
# pytesseract.pytesseract.tesseract_cmd = r"C:\\Program Files\\Tesseract-OCR\\tesseract.exe"

def read_text(img, lang: str = "eng") -> Dict[str, Any]:
    """Return recognized text and (optionally) positions later."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    text = pytesseract.image_to_string(gray, lang=lang)
    return {
        "text": text.strip()
    }
