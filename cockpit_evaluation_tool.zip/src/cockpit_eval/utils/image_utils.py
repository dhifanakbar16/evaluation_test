
"""General image helpers (conversions, normalization)."""
from __future__ import annotations
import cv2
import numpy as np

def to_gray(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
