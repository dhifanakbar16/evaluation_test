
"""Geometry helpers (distances, centers, areas)."""
from __future__ import annotations
from typing import Tuple
import math

def euclidean(p1: Tuple[float,float], p2: Tuple[float,float]) -> float:
    return math.dist(p1, p2)
