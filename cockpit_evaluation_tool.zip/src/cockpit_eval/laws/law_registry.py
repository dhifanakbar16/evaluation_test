
"""Law registry: load YAML and provide access to law rules.

- *Registry* just means: a structured place to store and retrieve definitions.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
from pathlib import Path
import yaml

@dataclass
class Law:
    id: str
    name: str
    applies_to: List[str]
    metrics: Dict[str, Any]

def load_laws(yaml_path: Path) -> List[Law]:
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    laws = []
    for law in data.get("laws", []):
        laws.append(Law(
            id=law["id"],
            name=law["name"],
            applies_to=law.get("applies_to", []),
            metrics=law.get("metrics", {}),
        ))
    return laws
