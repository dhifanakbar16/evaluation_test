
"""Apply laws to detected elements and compute pass/fail per metric.

- *Evaluate* means to compare a measured value against a rule (e.g., min/avg/max or range).
"""
from __future__ import annotations
from typing import List, Dict, Any, Tuple
import math

def _check_value_against_rule(value: float, rule: Dict[str, Any]) -> Tuple[bool, str]:
    """Return (passed, note). Supports keys: min, max, avg, range."""
    if "range" in rule:
        lo, hi = rule["range"]
        ok = lo <= value <= hi
        return ok, f"{lo} <= {value:.2f} <= {hi}"
    mins = rule.get("min")
    maxs = rule.get("max")
    # 'avg' is informational; you may compute distance from avg later
    if mins is not None and value < mins:
        return False, f"value {value:.2f} < min {mins}"
    if maxs is not None and value > maxs:
        return False, f"value {value:.2f} > max {maxs}"
    return True, "within limits"

def evaluate_elements_against_laws(elements: List[Dict[str, Any]], laws: List[Any]) -> List[Dict[str, Any]]:
    """Return flat rows with per-element, per-law, per-metric pass/fail.

    For now, we use placeholder measurements:
    - nearest_neighbor_distance: dummy 10.0
    - text_height_px: dummy 24.0 if type==text else None
    - contrast_ratio: dummy 4.5
    Replace with real measurements later.
    """
    results: List[Dict[str, Any]] = []

    # Precompute nearest neighbor distances if needed (placeholder)
    for elem in elements:
        elem.setdefault("metrics", {})
        elem["metrics"]["nearest_neighbor_distance"] = 10.0
        elem["metrics"]["contrast_ratio"] = 4.5
        if elem.get("type") == "text":
            elem["metrics"]["text_height_px"] = 24.0

    for elem in elements:
        for law in laws:
            if elem.get("type") not in law.applies_to:
                continue
            for metric, rule in law.metrics.items():
                value = elem["metrics"].get(metric)
                if value is None:
                    passed = False
                    note = "metric not available"
                else:
                    passed, note = _check_value_against_rule(float(value), rule)
                results.append({
                    "element_id": elem["id"],
                    "element_type": elem.get("type", "unknown"),
                    "law_id": law.id,
                    "law_name": law.name,
                    "metric": metric,
                    "value": value,
                    "passed": passed,
                    "note": note,
                })
    return results
