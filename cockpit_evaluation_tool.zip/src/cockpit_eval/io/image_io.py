
"""Image and CSV I/O (Input/Output).

- *I/O* means reading from and writing to files.
- We keep all file operations here so the rest of the code stays clean.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any

import cv2
import pandas as pd

def read_image(path: Path):
    """Read an image from disk as a numpy array (OpenCV uses BGR color order)."""
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Could not load image: {path}")
    return img

def save_image(path: Path, img) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), img)

def save_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(path, index=False)
