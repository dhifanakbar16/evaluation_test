
"""Configuration helpers and default constants.

- A *constant* is a fixed value you might reuse across the code.
- A *config function* might read a YAML file with user settings later.
"""

from dataclasses import dataclass
from pathlib import Path

@dataclass
class Paths:
    project_root: Path = Path(__file__).resolve().parents[2]
    data_dir: Path = project_root / "data"
    output_dir: Path = data_dir / "output"
    samples_dir: Path = data_dir / "samples"
    laws_yaml: Path = Path(__file__).resolve().parent / "laws" / "law_definitions.yaml"

paths = Paths()

# Default drawing settings for overlays
BOX_THICKNESS = 2
FONT_SCALE = 0.5
