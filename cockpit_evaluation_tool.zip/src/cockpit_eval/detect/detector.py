
"""Basic element detector (placeholder).

This module should locate elements (gauges, numbers, boxes) and return them as records.

A record is a Python dict like:
{
    "id": "elem_001",
    "type": "gauge",  # e.g., gauge, text, needle, box
    "bbox": [x, y, w, h],  # bounding box
    "center": [cx, cy],
    "area": w*h,
    "mean_color_bgr": [b, g, r],
    "color_hist": {"b": [...], "g": [...], "r": [...]},  # optional
}
"""
from __future__ import annotations
from typing import List, Dict, Any, Tuple

import cv2
import numpy as np

def detect_elements(img) -> List[Dict[str, Any]]:
    """Very simple placeholder detector using contours.

    Steps (high level):
    1) Convert to gray
    2) Threshold to binary
    3) Find contours (shapes)
    4) Filter by size/shape to get candidate elements
    5) Compute properties (center, area, mean color)

    Replace with real rules for your cockpit images.
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    contours, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    elements: List[Dict[str, Any]] = []
    for i, cnt in enumerate(contours):
        x, y, w, h = cv2.boundingRect(cnt)
        if w*h < 200:  # simple size filter to ignore tiny noise
            continue
        cx, cy = int(x + w/2), int(y + h/2)
        roi = img[y:y+h, x:x+w]
        mean_color = cv2.mean(roi)[:3]  # B,G,R (floats)
        elem = {
            "id": f"elem_{i:04d}",
            "type": "unknown",
            "bbox": [int(x), int(y), int(w), int(h)],
            "center": [int(cx), int(cy)],
            "area": int(w*h),
            "mean_color_bgr": [float(mean_color[0]), float(mean_color[1]), float(mean_color[2])],
        }
        elements.append(elem)

    return elements
