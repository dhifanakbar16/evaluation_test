
"""Color analysis utilities.

- *Color percentage* idea: what fraction of pixels in an element are within a target color range.
"""
from __future__ import annotations
from typing import Tuple
import cv2
import numpy as np

def color_percentage_bgr(roi, lower_bgr: Tuple[int,int,int], upper_bgr: Tuple[int,int,int]) -> float:
    mask = cv2.inRange(roi, lower_bgr, upper_bgr)
    total = roi.shape[0] * roi.shape[1]
    if total == 0:
        return 0.0
    return float(mask.sum() > 0) * (mask.sum() / 255.0) / total  # approximate fraction
