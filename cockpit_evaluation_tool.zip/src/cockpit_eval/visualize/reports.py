
"""Reporting helpers: CSV rows and heatmap figure."""
from __future__ import annotations
from typing import List, Dict, Any
import pandas as pd
import matplotlib.pyplot as plt

def make_results_dataframe(rows: List[Dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(rows)

def save_heatmap_png(df: pd.DataFrame, path):
    """Create a simple heatmap: elements vs laws (1=pass, 0=fail)."""
    # Pivot table: rows=element_id, cols=law_id, values=passed
    pivot = df.pivot_table(index="element_id", columns="law_id", values="passed", aggfunc="max").fillna(False)
    matrix = pivot.astype(int).values

    fig, ax = plt.subplots(figsize=(max(6, matrix.shape[1]*0.4), max(4, matrix.shape[0]*0.4)))
    ax.imshow(matrix, aspect='auto')
    ax.set_xticks(range(matrix.shape[1]))
    ax.set_xticklabels(pivot.columns, rotation=90)
    ax.set_yticks(range(matrix.shape[0]))
    ax.set_yticklabels(pivot.index)
    ax.set_xlabel("Law ID")
    ax.set_ylabel("Element ID")
    ax.set_title("Pass/Fail Heatmap (1=Pass, 0=Fail)")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
