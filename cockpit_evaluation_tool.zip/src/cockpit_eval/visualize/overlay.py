
"""Drawing overlays on images (boxes, labels)."""
from __future__ import annotations
from typing import List, Dict, Any, Tuple
import cv2

def draw_elements(img, elements: List[Dict[str, Any]]):
    canvas = img.copy()
    for e in elements:
        x, y, w, h = e["bbox"]
        label = f"{e.get('type','?')}:{e['id']}"
        cv2.rectangle(canvas, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(canvas, label, (x, y-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1, cv2.LINE_AA)
    return canvas
