
"""Top-level package for cockpit_eval.

This package contains modules to:
- load images
- detect elements (OpenCV)
- extract text (Tesseract OCR)
- evaluate against design laws
- visualize overlays and heatmaps
- export CSV reports
"""

__all__ = [
    "config",
    "io",
    "detect",
    "ocr",
    "laws",
    "evaluate",
    "visualize",
    "utils",
]
